import pygame
import random

# 定数
WIDTH, HEIGHT = 300, 600
BLOCK_SIZE = 30
ROWS, COLS = HEIGHT // BLOCK_SIZE, WIDTH // BLOCK_SIZE

# 色
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
COLORS = [
    (255, 0, 0),   # 赤
    (0, 255, 0),   # 緑
    (0, 0, 255),   # 青
    (255, 255, 0), # 黄
    (255, 0, 255), # マゼンタ
    (0, 255, 255), # シアン
    (255, 165, 0)  # オレンジ
]

# テトリスのブロック形状
SHAPES = [
    [[1, 1, 1, 1]],  # I
    [[1, 1], [1, 1]], # O
    [[0, 1, 0], [1, 1, 1]], # T
    [[1, 1, 0], [0, 1, 1]], # S
    [[0, 1, 1], [1, 1, 0]], # Z
    [[1, 0, 0], [1, 1, 1]], # L
    [[0, 0, 1], [1, 1, 1]], # J
]

class Tetris:
    def __init__(self):
        self.board = [[0] * COLS for _ in range(ROWS)]
        self.current_shape = self.new_shape()
        self.current_x, self.current_y = 4, 0

    def new_shape(self):
        return SHAPES[random.randint(0, len(SHAPES) - 1)]

    def rotate_shape(self):
        self.current_shape = [list(row) for row in zip(*self.current_shape[::-1])]

    def valid_position(self, offset_x, offset_y):
        for y, row in enumerate(self.current_shape):
            for x, value in enumerate(row):
                if value:
                    board_x = self.current_x + x + offset_x
                    board_y = self.current_y + y + offset_y
                    if board_x < 0 or board_x >= COLS or board_y >= ROWS or (board_y >= 0 and self.board[board_y][board_x]):
                        return False
        return True

    def lock_shape(self):
        for y, row in enumerate(self.current_shape):
            for x, value in enumerate(row):
                if value:
                    self.board[self.current_y + y][self.current_x + x] = 1
        self.current_shape = self.new_shape()
        self.current_x, self.current_y = 4, 0

    def draw(self, screen):
        screen.fill(BLACK)
        for y in range(ROWS):
            for x in range(COLS):
                if self.board[y][x]:
                    pygame.draw.rect(screen, WHITE, (x * BLOCK_SIZE, y * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE), 0)
        for y, row in enumerate(self.current_shape):
            for x, value in enumerate(row):
                if value:
                    pygame.draw.rect(screen, WHITE, ((self.current_x + x) * BLOCK_SIZE, (self.current_y + y) * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE), 0)

def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption('Tetris')
    clock = pygame.time.Clock()
    tetris = Tetris()
    
    running = True
    while running:
        clock.tick(10)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and tetris.valid_position(-1, 0):
            tetris.current_x -= 1
        if keys[pygame.K_RIGHT] and tetris.valid_position(1, 0):
            tetris.current_x += 1
        if keys[pygame.K_DOWN] and tetris.valid_position(0, 1):
            tetris.current_y += 1
        if keys[pygame.K_UP]:
            tetris.rotate_shape()
        
        if tetris.valid_position(0, 1):
            tetris.current_y += 1
        else:
            tetris.lock_shape()
        
        tetris.draw(screen)
        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()
