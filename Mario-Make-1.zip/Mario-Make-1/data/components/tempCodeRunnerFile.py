
                # self.walking_timer = self.current_time